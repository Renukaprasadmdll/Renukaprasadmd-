import React, { useState, useEffect } from 'react';
import { PlusCircle, Trash2, Trophy, Flame, Calendar, CheckCircle, Circle, ArrowRight, Target, Bell } from 'lucide-react';
import { Toaster, toast } from 'react-hot-toast';
import { supabase } from './lib/supabase';
import AuthForm from './components/AuthForm';
import Dashboard from './components/Dashboard';

interface Habit {
  id: number;
  name: string;
  streak: number;
  completedDates: string[];
  color: string;
  target: number;
  lastNotification?: string;
}

const COLORS = [
  'bg-blue-500',
  'bg-purple-500',
  'bg-pink-500',
  'bg-green-500',
  'bg-yellow-500',
  'bg-red-500',
];

function App() {
  const [session, setSession] = useState<any>(null);
  const [showHabits, setShowHabits] = useState(false);
  const [habits, setHabits] = useState<Habit[]>(() => {
    const saved = localStorage.getItem('habits');
    return saved ? JSON.parse(saved) : [];
  });
  const [newHabit, setNewHabit] = useState('');
  const [selectedTarget, setSelectedTarget] = useState(7);
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      setShowHabits(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (session?.user?.id) {
      localStorage.setItem('habits', JSON.stringify(habits));
    }
  }, [habits, session?.user?.id]);

  useEffect(() => {
    if (notificationsEnabled) {
      const checkHabits = () => {
        const today = new Date().toISOString().split('T')[0];
        habits.forEach(habit => {
          if (!habit.completedDates.includes(today) && habit.lastNotification !== today) {
            toast((t) => (
              <div className="flex items-center gap-3">
                <Bell className="text-indigo-500" size={20} />
                <span>Don't forget to complete: {habit.name}</span>
              </div>
            ), {
              duration: 5000,
              position: 'bottom-right',
            });
            
            // Update last notification date
            setHabits(habits.map(h =>
              h.id === habit.id ? { ...h, lastNotification: today } : h
            ));
          }
        });
      };

      // Check every 2 hours
      const interval = setInterval(checkHabits, 2 * 60 * 60 * 1000);
      // Initial check
      checkHabits();

      return () => clearInterval(interval);
    }
  }, [habits, notificationsEnabled]);

  const addHabit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newHabit.trim()) {
      const color = COLORS[Math.floor(Math.random() * COLORS.length)];
      setHabits([...habits, {
        id: Date.now(),
        name: newHabit.trim(),
        streak: 0,
        completedDates: [],
        color,
        target: selectedTarget
      }]);
      setNewHabit('');
      toast.success('New habit created!');
    }
  };

  const toggleHabit = (habit: Habit) => {
    const today = new Date().toISOString().split('T')[0];
    const isCompleted = habit.completedDates.includes(today);
    
    let newCompletedDates;
    if (isCompleted) {
      newCompletedDates = habit.completedDates.filter(date => date !== today);
      toast.error('Habit marked as incomplete');
    } else {
      newCompletedDates = [...habit.completedDates, today];
      if (habit.streak === habit.target - 1) {
        toast.success('🎉 Congratulations! You\'ve reached your target!', {
          icon: '🏆',
          duration: 5000
        });
      } else {
        toast.success('Habit completed for today!');
      }
    }

    // Calculate streak
    let streak = 0;
    const sortedDates = [...newCompletedDates].sort();
    if (sortedDates.length > 0) {
      streak = 1;
      for (let i = 1; i < sortedDates.length; i++) {
        const prev = new Date(sortedDates[i - 1]);
        const curr = new Date(sortedDates[i]);
        const diffDays = Math.floor((curr.getTime() - prev.getTime()) / (1000 * 60 * 60 * 24));
        if (diffDays === 1) streak++;
        else break;
      }
    }

    setHabits(habits.map(h =>
      h.id === habit.id
        ? { ...h, completedDates: newCompletedDates, streak }
        : h
    ));
  };

  const deleteHabit = (id: number) => {
    setHabits(habits.filter(habit => habit.id !== id));
    toast.success('Habit deleted');
  };

  const calculateProgress = (habit: Habit) => {
    return Math.min((habit.completedDates.length / habit.target) * 100, 100);
  };

  if (!session) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 py-12 px-4">
        <div className="max-w-md mx-auto">
          <div className="text-center mb-8">
            <Target className="text-white mx-auto" size={48} />
            <h1 className="text-4xl font-bold text-white mt-4">Habit Tracker</h1>
            <p className="text-white/80 mt-2">Build better habits, achieve your goals</p>
          </div>
          <div className="bg-white rounded-xl shadow-2xl p-8">
            <AuthForm />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 py-12 px-4">
      <Toaster position="top-right" />
      <div className="max-w-2xl mx-auto">
        {!showHabits ? (
          <Dashboard email={session.user.email} onShowHabits={() => setShowHabits(true)} />
        ) : (
          <div className="bg-white rounded-xl shadow-2xl p-8">
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center gap-3">
                <Target className="text-indigo-500" size={32} />
                <h1 className="text-4xl font-bold text-gray-800">
                  Habit Tracker
                </h1>
              </div>
              <button
                onClick={() => setNotificationsEnabled(!notificationsEnabled)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors duration-200 ${
                  notificationsEnabled
                    ? 'bg-indigo-500 text-white'
                    : 'bg-gray-100 text-gray-600'
                }`}
              >
                <Bell size={20} />
                {notificationsEnabled ? 'Notifications On' : 'Notifications Off'}
              </button>
            </div>

            <form onSubmit={addHabit} className="mb-8 space-y-4">
              <div className="flex gap-3">
                <input
                  type="text"
                  value={newHabit}
                  onChange={(e) => setNewHabit(e.target.value)}
                  placeholder="Enter a new habit..."
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                />
                <select
                  value={selectedTarget}
                  onChange={(e) => setSelectedTarget(Number(e.target.value))}
                  className="px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                >
                  {[7, 14, 21, 30, 60, 90].map(days => (
                    <option key={days} value={days}>{days} days</option>
                  ))}
                </select>
                <button
                  type="submit"
                  className="bg-indigo-500 text-white px-6 py-3 rounded-lg hover:bg-indigo-600 transition-colors duration-200 flex items-center gap-2"
                >
                  <PlusCircle size={20} />
                  Add
                </button>
              </div>
            </form>

            <div className="space-y-4">
              {habits.map(habit => {
                const progress = calculateProgress(habit);
                const today = new Date().toISOString().split('T')[0];
                const isCompletedToday = habit.completedDates.includes(today);

                return (
                  <div
                    key={habit.id}
                    className="bg-gray-50 rounded-lg p-6 group relative hover:shadow-md transition-shadow duration-200"
                  >
                    <div className="flex items-center gap-4 mb-3">
                      <button
                        onClick={() => toggleHabit(habit)}
                        className="text-gray-400 hover:text-indigo-500 transition-colors"
                      >
                        {isCompletedToday ? (
                          <CheckCircle className="text-green-500" size={28} />
                        ) : (
                          <Circle size={28} />
                        )}
                      </button>
                      <div className="flex-1">
                        <h3 className="text-xl font-semibold text-gray-800">{habit.name}</h3>
                        <div className="flex items-center gap-2 text-gray-500">
                          <Calendar size={16} />
                          <span>{habit.completedDates.length} / {habit.target} days</span>
                          {habit.streak > 0 && (
                            <>
                              <ArrowRight size={16} />
                              <Flame className="text-orange-500" size={16} />
                              <span className="text-orange-500">{habit.streak} day streak!</span>
                            </>
                          )}
                        </div>
                      </div>
                      <button
                        onClick={() => deleteHabit(habit.id)}
                        className="text-gray-400 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                      >
                        <Trash2 size={20} />
                      </button>
                    </div>

                    <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div
                        className={`h-full ${habit.color} transition-all duration-500`}
                        style={{ width: `${progress}%` }}
                      />
                    </div>

                    {progress >= 100 && (
                      <div className="absolute -top-2 -right-2">
                        <Trophy className="text-yellow-500" size={24} />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {habits.length === 0 && (
              <div className="text-center text-gray-500 mt-8">
                <Target size={48} className="mx-auto mb-4 text-gray-400" />
                <p className="text-xl">No habits tracked yet. Add one to get started!</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default App;