import React from 'react';
import { Target, User, LogOut, Bell, Award } from 'lucide-react';
import { supabase } from '../lib/supabase';
import toast from 'react-hot-toast';

interface DashboardProps {
  email: string;
  onShowHabits: () => void;
}

export default function Dashboard({ email, onShowHabits }: DashboardProps) {
  const handleSignOut = async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      toast.success('Signed out successfully');
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-2xl p-8 mb-8">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-4">
          <div className="bg-indigo-100 p-3 rounded-full">
            <User className="text-indigo-500" size={24} />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-800">Welcome back!</h2>
            <p className="text-gray-600">{email}</p>
          </div>
        </div>
        <button
          onClick={handleSignOut}
          className="text-gray-500 hover:text-red-500 transition-colors duration-200 flex items-center gap-2"
        >
          <LogOut size={20} />
          Sign Out
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div 
          className="bg-gradient-to-br from-indigo-500 to-purple-500 rounded-lg p-6 text-white cursor-pointer hover:shadow-lg transform hover:-translate-y-1 transition-all duration-200"
          onClick={onShowHabits}
        >
          <Target size={32} className="mb-4" />
          <h3 className="text-xl font-semibold mb-2">Track Your Habits</h3>
          <p>Start building better habits today</p>
          <div className="mt-4 text-white/80 flex items-center gap-2">
            <Bell size={16} />
            <span>Get reminders and stay on track</span>
          </div>
        </div>
        <div className="bg-gradient-to-br from-pink-500 to-red-500 rounded-lg p-6 text-white">
          <Award size={32} className="mb-4" />
          <h3 className="text-xl font-semibold mb-2">Your Progress</h3>
          <div className="space-y-2">
            <p className="flex items-center gap-2">
              <Bell size={16} />
              <span>Daily notifications to keep you motivated</span>
            </p>
            <p className="flex items-center gap-2">
              <Target size={16} />
              <span>Set and achieve your goals</span>
            </p>
            <p className="flex items-center gap-2">
              <Award size={16} />
              <span>Earn achievements as you progress</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}